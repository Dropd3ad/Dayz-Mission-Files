Banov Server Files
This repo contains all the necessary information and files for an Banov server

Server Installation
Make sure you have up-to-date @Banov folder in your server root. Copy Banov.bikey from Keys folder to your server root keys folder.

Frequently Asked Questions (FAQ)
Q: Can I add my own locations on the map?:

A: Yes.

Q: Can I repack Banov?

A: Fuck No.

Q: What is the suggested player count for Banov?

60/120
Q: Can I add new types to the existing vanilla Banov setup?

A: Yes.

Q: I need help with something I could not find in this FAQ section.

A: Join us in Banov Discord and react to the message in the #welcome channel to get a server owner role.

Q: Did you just copy-paste Sumrak's readme file for Namalsk,Esseker and then just adjust it to fit Banov like a pesant?

A: Yes.

Q: Are you at least grateful to Sumrak?

A: Yes.
